import requests
import bs4
import time
import sys

base_url = "https://www.amazon.com/best-sellers-books-Amazon/zgbs/books/ref=zg_bs_pg_1?_encoding=UTF8&pg=1"         #this is the link to the website we want to scrape
print("Please hold on...\n")    #this code is used to account for the time it takes for the code to run and get the required information from amazon
time.sleep(1)

# To create a soup object
def make_soup(url):
    # the try and except code below takes care of unexpected problems such as a network failure.
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) '
                          'Chrome/56.0.2924.76 '
                          'Safari/537.36',      #takes into consideration different popular browsers that users might use
            "Upgrade-Insecure-Requests": "1",
            "DNT": "1",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,/;q=0.8",
            "Accept-Language": "en-US,en;q=0.5",
            "Accept-Encoding": "gzip, deflate"
        }
        res = requests.get(url, headers=headers, params={"wait": 2})
        soup = bs4.BeautifulSoup(res.text, "lxml")
        return soup
    except requests.exceptions.RequestException as e:
        print("Something went wrong", e)

def books_component(s):
    if not len(s.select(".zg-item-immersion")):
        print("An error occured. Please run the program again")
        sys.exit()
    else:
        return s.select(".zg-item-immersion")

# To get the list of most popular books
def get_popular_books(s):
    popular_books = []
    for item in books_component(s):
        if "a-star-5" in str(item):
            for book_names in item.select(".p13n-sc-truncate"):
                popular_books.append(book_names.getText().strip())
    return popular_books

# To get the prices for the most popular books above
def popular_books_prices(s):
    prices_of_popular_books = []
    for item in books_component(s):
        if "a-star-5" in str(item):
            for prices in item.find(name="span", class_="p13n-sc-price"):
                prices_of_popular_books.append(float(prices.getText().replace("$", "")))
    return prices_of_popular_books

# To get the top 10 prices from the most popular books above
def top_ten_prices(s):
    top_ten = []
    for price in popular_books_prices(s):
        top_ten.append(price)
    max_range = 10
    top_ten.sort()
    top_ten = top_ten[-max_range:]
    return top_ten

# To arrange the prices above in order to get top 10 most expensive books
def top_most_expensive(s):
    ten_most_expensive = []
    unsorted_prices = []
    for item in books_component(s):
        if "a-star-5" in str(item):
            for val in top_ten_prices(s):
                if f"${val}" in str(item):
                    ten_most_expensive.append(item.find(name="div", class_="p13n-sc-truncate").text.strip())
                    for prices in item.find(name="span", class_="p13n-sc-price"):
                        unsorted_prices.append(prices)
    return [{ten_most_expensive[i]: unsorted_prices[i] for i in range(len(ten_most_expensive))}]

# To ensure that the code works for sites that have multiple pages.
for x in range(1, 99):
    soup = make_soup(
        f"https://www.amazon.com/best-sellers-books-Amazon/zgbs/books/ref=zg_bs_pg_1?_encoding=UTF8&pg={x}")
    top_most_expensive(soup)
    if not soup.find("li", {"class": "a-disabled a-last"}):
        pass
    else:
        break

# Call all the functions
soup_object = make_soup(base_url)
books_component(soup_object)
get_popular_books(soup_object)
popular_books_prices(soup_object)
top_ten_prices(soup_object)
print(top_most_expensive(soup_object))