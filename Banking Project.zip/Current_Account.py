from Account import  Account

#Create a class for a user who wants to create a current account
class CurrentAccount(Account):
    #for withdrawal from a current account using the 1% interest rate
    def current_withdraw(self,month):
        if month >= 1:
            print("Your account has been registered for {}".format(month))
            self.add_interest(month)
        self.withdraw()
     #interest function that adds interest to users balance
    def add_interest(self,month):
        self.balance = (self.balance * 0.01 * month) + self.balance
        print("Congratulations! You now have {} interest added to your account".format(self.balance * 0.01 * month))
        print("Your current balance is {}".format(self.balance))