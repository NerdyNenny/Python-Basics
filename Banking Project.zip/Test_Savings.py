import unittest
#to test if the savings account runs properly
from Savings_Account import SavingsAccount
def withdraw (lst):
    account_owner = input("Please enter your full name: ")
    test_pin = int(input("Please enter your pin: "))
    month = int(input("How many months have you been using your account?: "))
    for account in lst:
        if account.name == account.owner and account.pin == test_pin and account.a_type == "SAVINGS":
            account.savings_withdraw(month)
            return False
    print("Sorry, we do not recognise your account")




