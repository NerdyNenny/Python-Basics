import unittest
from Current_Account import CurrentAccount
from Savings_Account import SavingsAccount
import Test_Current as TC
import Test_Savings as TS

#code to help users create account
def create_account(lst):
    count = 0
    while True:
        answer = int(input("What type of account would you like to creat?\n"
                            "1. Savings account\n  2. Current Account\n"))
        if answer == 1:
            new_account = SavingsAccount("SAVINGS")
            lst.append(new_account)
            print("Congratulations! You have created a Savings Account!")
            break
        elif answer == 2:
            new_account = CurrentAccount("CURRENT")
            lst.append(new_account)
            print("Congratulations1 You have created a Current Account!")
            break
        count += 1

#code to check account balance
def check_balance(lst):
    account_owner = input("Please enter your full name: ")
    pin = int(input("Please enter your pin: "))

    for account in lst:
        if account.name == account_owner and account.pin == pin:
            account.check_balance()
            return (0)
    print("Sorry, we do not recognise your account.")

#code to transfer money
def user_transfer(lst):
    account_owner = input("Please enter your full name: ")
    pin = int(input("Please enter your pin: "))
    receiver = input("Please enter full name of receiver")
    for account in lst:
        if account.name == account_owner and account.pin == pin:
            for account2 in lst:
                if account2.name == receiver:
                    account.user_transfer(account2)
                    return (0)
            return (0)
        print("Sorry, we do not recognise your account.")

#code to deposit money
def make_a_deposit(lst):
    account_owner = input("Please enter your full name: ")
    pin = int(input("Please enter your pin: "))
    for account in lst:
        if account.name == account_owner and account.pin == pin:
            account.deposit()
            return (0)
    print("Sorry, we do not recognise your account.")

#code to withdraw
def withdraw(lst):
    account_type = int(input("What type of account would you like to creat?\n"
                            "1. Savings account\n  2. Current Account\n"))
    if account_type == 1:
        TS.withdraw(lst)
    elif account_type == 2:
        TC.withdraw(lst)










