import unittest
#to test if the current account runs properly
from Current_Account import CurrentAccount
def withdraw(lst):
    account_owner1 = input("Please enter your full name: ")
    test_pin1 = int(input("Please enter your pin: "))
    month = int(input("How many months have you been using your account?: "))
    for account in lst:
        if account.name == account.owner1 and account.pin == test_pin1 and account.a_type == "CURRENT":
            account.savings_withdraw(month)
            return False
    print("Sorry, we do not recognise your account")




