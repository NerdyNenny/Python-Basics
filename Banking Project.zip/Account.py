#Creating an Account class which will be the parent class
class Account:
    def __init__(self, a_type):                     #a_type is the account type which can be either current or savings
        account_name = input("Please write your full name here: ")
        count = 0
        while True:
            pin = int(input("Enter a four-digit pin: "))
            if len(pin) == 4:
                print("Pin created successfully!".format(pin))
            elif len(pin) != 4:
                print("Sorry, your pin must be four-digit.".format(pin))
                break
            count += 1
        self.account_name = account_name
        self.pin = pin
        self.a_type = a_type
        self.balance = 0

    #code to deposit money
    def deposit(self):
        amount = int(input("Enter the amount you want to deposit: "))
        print("You have successfully deposited{}\n".format(amount))
        self.balance += amount
        print("Your account balance is {}\n".format(self.balance))

    #code to withdraw money
    def withdraw(self):
        amount = int(input("Enter the amount you want to withdraw: "))
        if amount >= self.balance:
            print("Sorry, you do not have sufficient funds to perform this transaction")
            print("Your balance is {}".format(self.balance))
            response = input("Would you like to withdraw a smaller amount? (yes/no)")
            if response in ["yes", "Yes"]:
                return amount
            else:
                pass
        else:
            rate = amount * 0.01       #applying the 1% interest rate on the account balance
            self.balance = self.balance - amount - rate        #to find the remaining balance after withdrawing
            print("You have withdrawn {} from your account".format(self.account_name))
            print("Your balance is {}".format(self.balance))

    #code to transfer money to another account
    def transfer(self, rem):
        while True:
            amount = int(input("Enter the amount you want to transfer: "))
            if amount + amount * 0.02 <= self.balance:
                break
            else:
                print("You do not have sufficient funds to perform this transaction")
                print("Your balance is {}".format(self.balance))
                response = input("Do you still want to transfer money? (yes/no): ")
                if response in ["yes", "Yes"]:
                    return 0

        rate = amount * 0.02
        self.balance = self.balance - rate - amount
        obj.balance += amount
        print("You have successfully transferred {} from your account".format(amount))
        print("Your balance is {}".format(self.balance))

    #code to view account balance
    def account_balance(self):
        print("Your balance is {}".format(self.balance))

    def __str__(self):
        return("""Account user: {}
        Balance: {} """.format(self.name,self.balance))






