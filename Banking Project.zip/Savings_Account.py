from Account import Account

#to create a child class for users who open savings account
class SavingsAccount(Account):
    # for withdrawal from a savings account using the given limitations
    def savings_withdraw(self,month):
        if month >= 6:
            print("Your account has been registered for {}".format(month))
            print("You can now withdraw from your account")
            self.add_interest(month)
            self.withdraw()
            return True
        else:
            print("Your account has been registered for {}".format(month))
            print("You are not aloowed to withraw until your account is 6 months old")
            return False

    #to calculate and add interest every month (3%)
    def add_interest(self,month):
        self.balance = (self.balance * 0.03 * month) + self.balance
        print("Congratulations! You now have {} interest added to your account".format(self.balance * 0.03 * month))
        print("Your current balance is {}".format(self.balance))