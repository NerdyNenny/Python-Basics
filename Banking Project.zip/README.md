# Programming-1_Assignment-3_Week-7_2021
Assignment 3
Congratulations, you have made it this far :)
This assignment is easy, because you are building on things that you already have done.

This one has a bit of a lot of things to do but it is easy.

In this assignment we are testing your understanding of classes, inheritance and whether you can design and implement one correctly

Here is the invite link (https://classroom.github.com/a/S3zwml1Y)  to accept the assignment on github

 

Question 1 [25 marks]
Dangote has a lot of money. Dangote wants to open a bank. Each client has his own bank account. Each client can deposit money on their account, withdraw money from their account, view their bank balance and transfer money from their account to another client using Dangote’s bank. Please help Dangote.

Question 2 [25 marks]
Dangote is happy with your help so far, but he would like to make some changes.

He would like to introduce saving accounts and current accounts.

If you deposit money in a current account and the money stays for one month, you get an interest of 1%, but if you have a savings account, the interest is 3% and you can only withdraw after 6 months.



