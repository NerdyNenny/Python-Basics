import Test_Account as test
list_of_account = []

# to provide user with the main menu of transactions
print("Welcome to Dangote Bank. What transaction would you like to perform?\n")
while True:
    transaction = int(input("MAIN MENU\n"
                            "Press 1 to create a new account\n"
                            "Press 2 to check your balance\n"
                            "Press 3 for withdrawals\n"
                            "Press 4 for transfers\n"
                            "Press 5 to deposit money\n"
                            "Press 6 to exit\n"))
    if transaction == 1:
        test.create_account(list_of_account)
    elif transaction == 2:
        test.see_balance(list_of_account)
    elif transaction == 3:
        test.withdraw(list_of_account)
    elif transaction == 4:
        test.transfer_money(list_of_account)
    elif transaction == 5:
        test.make_a_deposit(list_of_account)
    else:
        print("Thank you for banking with Dangote")
        break