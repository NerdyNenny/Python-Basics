import random
import itertools
import pickle

class Headspace:

    def __init__(self):
        self.users = {}
        self.paid_users = []
        self.room1 = {}
        self.room2 = {}
        self.room3 = {}
        self.room4 = {}
        self.room5 = {}
        self.room6 = {}
        self.room7 = {}
        self.room8 = {}
        self.times = ['10', '10:45', '11:30','12:15', '1:00', '1:45', '2:30','3:15','4:00','4:45','5:30','6:15']
        self.days = [1, 2, 3, 4, 5, 6]
        self.tips = ["sleep early", "stop overthinking", "take a walk"]
        self.given = []

    def ask(self):
        inputt = input("Enter here...").strip().replace(" ", "").lower()
        return inputt

    def signup_error(self,email):
        print("email exists, enter A to login to that account, B to signup for another account")
        choice = self.ask()
        if choice == "a":
            self.login()
        elif choice == "b":
            self.signup()
        else:
            print("Invalid response, try again")
            self.signup_error(email)

    def signup(self):
        print("Email")
        email = self.ask()
        with open('users.data', 'rb') as file:
            # read the data as binary data stream
            self.users = pickle.load(file)
        file.close()
        if email in self.users.keys():
            self.signup_error(email)
        else:
            print("Password")
            password = self.ask()
            self.users[email] = password
            print("Signup successful", email)

            with open((email + '.data'),"wb") as file:
                pickle.dump({},file)
            file.close()

            with open((email + '.data'),"rb") as file:
                user = pickle.load(file)
                user["email"] = email
                user["password"] = password
            file.close()

            with open((email + '.data'),"wb") as file:
                pickle.dump(user,file)
            file.close()

            with open('users.data', 'wb') as file:
                pickle.dump(self.users, file)
            file.close()
        return email

    def login_error(self,email):
        print("email doesn't exist, enter A to login to another account, B to signup for an account")
        choice = self.ask()
        if choice == "a":
            self.login()
        elif choice == "b":
            self.signup()
        else:
            print("Invalid response, try again")
            self.login_error(email)

    def password_error(self,email):
        with open('users.data', 'rb') as file:
            # read the data as binary data stream
            self.users = pickle.load(file)
        print("password........")
        password = self.ask()
        if password == self.users[email]:
            print("Login successful")
        else:
            print("incorrect password")
            self.password_error(email)

    def login(self):
        with open('users.data', 'rb') as file:
            # read the data as binary data stream
            self.users = pickle.load(file)
        file.close()
        print("Email")
        email = self.ask()
        if email not in self.users.keys():
            self.login_error(email)
        else:
           self.password_error(email)
           self.tip(email)
           return email

    def tip(self,email):
        with open('given.data', 'rb') as file:
            # read the data as binary data stream
            self.given = pickle.load(file)
        file.close()
        email_tips = self.tips
        for tip in email_tips:
            if [email,tip] in self.given:
                email_tips.remove(tip)
        tip = random.choice(email_tips)
        print("Coping tip for today:", tip)
        self.given.append([email,tip])
        with open('given.data', 'wb') as file:
            pickle.dump(self.given, file)
        file.close()

    def art(self,email):
        print("Welcome to the Art therapy session \n You're being assigned to room 1")
        randos = list(itertools.product(self.days, self.times))
        with open('room1.data', 'rb') as file:
            # read the data as binary data stream
            self.room1 = pickle.load(file)
        file.close()
        for r in randos:
            if r in self.room1.keys():
                randos.remove(r)
        date = self.time(randos)
        if date in self.room1.keys():
            print("Choice is booked already, try again")
            self.art(email)
        elif date in randos:
            self.room1[date] = email
            with open('room1.data', 'wb') as file:
                pickle.dump(self.room1, file)
            file.close()

            with open((email + '.data'),"rb") as file:
                user = pickle.load(file)
                if "art_booking" in user.keys():
                    user["art_booking"].append(date)
                else:
                    user["art_booking"] = [date]
            file.close()

            with open((email + '.data'),"wb") as file:
                pickle.dump(user, file)
            file.close()
            print("Booking session..........")
        else:
            print("Invalid choice, try again")
            self.art(email)

    def haiku(self,email):
        print("Welcome to the Haiku therapy session \n You're being assigned to room 3")
        randos = list(itertools.product(self.days, self.times))
        with open('room3.data', 'rb') as file:
            # read the data as binary data stream
            self.room3 = pickle.load(file)
            file.close()
        for r in randos:
            if r in self.room3.keys():
                randos.remove(r)
        date = self.time(randos)
        if date in self.room3.keys():
            print("Choice is booked already, try again")
            self.haiku(email)
        elif date in randos:
            self.room3[date] = email

            with open((email + '.data'),"rb") as file:
                user = pickle.load(file)
                if "haiku_booking" in user.keys():
                    user["haiku_booking"].append(date)
                else:
                    user["haiku_booking"] = [date]
            file.close()

            with open((email + '.data'),"wb") as file:
                pickle.dump(user, file)
            file.close()

            with open('room3.data', 'wb') as file:
                pickle.dump(self.room3, file)
            file.close()
            print("Booking session..........")
        else:
            print("Invalid choice, try again")
            self.haiku(email)

    def exercise(self,email):
        print("Welcome to the Exercise therapy session \n You're being assigned to room 5")
        randos = list(itertools.product(self.days, self.times))
        with open('room5.data', 'rb') as file:
            # read the data as binary data stream
            self.room5 = pickle.load(file)
        file.close()
        for r in randos:
            if r in self.room5.keys():
                randos.remove(r)
        date = self.time(randos)
        if date in self.room5.keys():
            print("Choice is booked already, try again")
            self.exercise(email)
        elif date in randos:
            self.room5[date] = email

            with open((email + '.data'),"rb") as file:
                user = pickle.load(file)
                if "exercise_booking" in user.keys():
                    user["exercise_booking"].append(date)
                else:
                    user["exercise_booking"] = [date]
            file.close()

            with open((email + '.data'),"wb") as file:
                pickle.dump(user, file)
            file.close()

            with open('room5.data', 'wb') as file:
                pickle.dump(self.room5, file)
            file.close()
            print("Booking session..........")
        else:
            print("Invalid choice, try again")
            self.exercise(email)

    def consultation(self,email):
        print("Welcome to the consultation session \n You're being assigned to room 7")
        randos = list(itertools.product(self.days, self.times))
        with open('room7.data', 'rb') as file:
            # read the data as binary data stream
            self.room7 = pickle.load(file)
        file.close()
        for r in randos:
            if r in self.room7.keys():
                randos.remove(r)
        date = self.time(randos)
        if date in self.room7.keys():
            print("Choice is booked already, try again")
            self.consultation(email)
        elif date in randos:
            self.room7[date] = email
            with open((email + '.data'),"rb") as file:
                user = pickle.load(file)
                if "consultation_booking" in user.keys():
                    user["consultation_booking"].append(date)
                else:
                    user["consultation_booking"] = [date]
            file.close()

            with open((email + '.data'),"wb") as file:
                pickle.dump(user, file)
            file.close()
            with open('room7.data', 'wb') as file:
                pickle.dump(self.room7, file)
            file.close()
            print("Booking session..........")
        else:
            print("Invalid choice, try again")
            self.consultation(email)

    def time(self,randos):
        if randos == []:
            print("All sessions are booked")
        else:
            print("These are the times and days for sessions available.\n Enter the date preferred in the format displayed below")
            for x,y in randos:
                print( "0" + str(x) + " - " + y)
            date = self.ask()
            try:
                return (int(date[1]),date[3:7])
            except IndexError:
                pass
            except ValueError:
                pass

    def pay(self,email):
        with open('paid_users.data', 'rb') as file:
            # read the data as binary data stream
            self.paid_users = pickle.load(file)
        file.close()
        bill = 10
        print("Enter A if the booking is one off \n Enter B if the booking is monthly \n Enter C if the booking is yearly")
        booking = self.ask()
        if booking == "a":
            print("calculating bill......\n Your bill is $",bill)
        elif booking == "b":
            bill = bill * 95/100
            print("calculating bill......\n You get a discount of 5% \n Your bill is $",bill)
        elif booking == "c":
            bill = bill * 90/100
            print("calculating bill......\n You get a discount of 10% \n Your bill is $", bill )
        else:
            print("Invalid input, try again")
            self.pay(email)
        with open((email + '.data'), "rb") as file:
            user = pickle.load(file)
            if "payments" in user.keys():
                user["payments"].append("$" + str(bill))
            else:
                user["payments"] = [("$" + str(bill))]
        file.close()

        with open((email + '.data'), "wb") as file:
            pickle.dump(user, file)
        file.close()

        if email in self.paid_users:
            print ("kindly pay on arrival")
        else:
            bill = bill * 90 / 100
            print("As a new customer, you get a 10% discount \n Your new bill is ", bill)
            print("Kindly pay on arrival")
        self.paid_users.append(email)
        with open('paid_users.data', 'wb') as file:
            pickle.dump(self.paid_users, file)
        file.close()

    def menu(self):
        print("Welcome to my headspace \n Enter A to Login or B to Signup")
        choice = self.ask()
        if choice == "a":
            email = self.login()
            self.choices(email)
        elif choice == "b":
            email = self.signup()
            self.choices(email)
        else:
            print("invalid response")
            self.menu()

    def choices(self,email):
        print("Which service do you want to perform? \n Enter A for haiku \n Enter B for art \n Enter C for exercise \n Enter D for a consultation \n  Enter E to view userdata")
        choice = self.ask()
        if choice == "a":
            self.haiku(email)
            self.pay(email)
            self.again(email)
        elif choice == "b":
            self.art(email)
            self.pay(email)
            self.again(email)
        elif choice == "c":
            self.exercise(email)
            self.pay(email)
            self.again(email)
        elif choice == "d":
            self.consultation(email)
            self.pay(email)
            self.again(email)
        elif choice == "e":
            self.userdata(email)
        else:
            print("Invalid input, try again")
            self.choices(email)

    def again(self,email):
        print("Do you want to perform any other transaction? \n Enter Yes or No")
        choice = self.ask()[0]
        if choice == "y":
            self.choices(email)
        elif choice == "n":
            print("Thank you for using my headspace")
        else:
            print("Invalid input, try again")
            self.again(email)

    def userdata(self,email):
        with open((email + '.data'), "rb") as file:
            data = pickle.load(file)
            print(data)
        file.close()


class Group(Headspace):
    def haiku(self,email):
        print("Welcome to the Haiku therapy session \n You're being assigned to room 4")
        randos = list(itertools.product(self.days, self.times))
        with open('room4.data', 'rb') as file:
            # read the data as binary data stream
            self.room4 = pickle.load(file)
        file.close()
        room = [x for x in self.room4.keys()]
        for r in randos:
            if room.count(r) > 11:
                randos.remove(r)
        date = self.time(randos)
        if date in self.room4.keys():
            if self.room4[date] == email:
                print("You can't book twice in the same group session, try again")
                self.haiku(email)
        elif room.count(date) > 11:
            print("This session is booked solid, try another one")
            self.haiku(email)
        elif date in randos:
            self.room4[date] = email

            with open((email + '.data'),"rb") as file:
                user = pickle.load(file)
                if "haiku_group_booking" in user.keys():
                    user["haiku_group_booking"].append(date)
                else:
                    user["haiku_group_booking"] = [date]
            file.close()

            with open((email + '.data'),"wb") as file:
                pickle.dump(user, file)
            file.close()
            with open('room4.data', 'wb') as file:
                pickle.dump(self.room4, file)
            file.close()
            print("Booking session..........")
        else:
            print("Invalid choice, try again")
            self.haiku(email)

    def art(self, email):
        print("Welcome to the Art therapy session \n You're being assigned to room 2")
        randos = list(itertools.product(self.days, self.times))
        with open('room2.data', 'rb') as file:
            # read the data as binary data stream
            self.room2 = pickle.load(file)
        file.close()
        file.close()
        room = [x for x in self.room2.keys()]
        for r in randos:
            if room.count(r) > 11:
                randos.remove(r)
        date = self.time(randos)

        if date in self.room2.keys():
            if self.room2[date] == email:
                print("You can't book twice in the same group session, try again")
                self.art(email)

        if room.count(date) > 11:
            print("This session is booked solid, try another one")
            self.art(email)
        elif email in self.room2.items():
            print("You can't book twice in the same group session")
            self.art(email)
        elif date in randos:
            self.room2[date] = email

            with open((email + '.data'),"rb") as file:
                user = pickle.load(file)
                if "art_group_booking" in user.keys():
                    user["art_group_booking"].append(date)
                else:
                    user["art_group_booking"] = [date]
            file.close()

            with open((email + '.data'),"wb") as file:
                pickle.dump(user, file)
            file.close()
            with open('room2.data', 'wb') as file:
                pickle.dump(self.room2, file)
            file.close()
            print("Booking session..........")
        else:
            print("Invalid choice, try again")
            self.art(email)

    def exercise(self, email):
        print("Welcome to the Haiku therapy session \n You're being assigned to room 6")
        randos = list(itertools.product(self.days, self.times))
        with open('room6.data', 'rb') as file:
            # read the data as binary data stream
            self.room6 = pickle.load(file)
        file.close()
        room = [x for x in self.room6.keys()]
        for r in randos:
            if room.count(r) > 11:
                randos.remove(r)
        date = self.time(randos)

        if date in self.room6.keys():
            if self.room6[date] == email:
                print("You can't book twice in the same group session, try again")
                self.exercise(email)
        if room.count(date) > 11:
            print("This session is booked solid, try another one")
            self.exercise(email)
        elif email in self.room6.items():
            print("You can't book twice in the same group session")
            self.exercise(email)
        elif date in randos:
            self.room6[date] = email
            with open((email + '.data'),"rb") as file:
                user = pickle.load(file)
                if "exercise_group__booking" in user.keys():
                    user["exercise_group_booking"].append(date)
                else:
                    user["exercise_group_booking"] = [date]
            file.close()

            with open((email + '.data'),"wb") as file:
                pickle.dump(user, file)
            file.close()
            with open('room6.data', 'wb') as file:
                pickle.dump(self.room6, file)
            file.close()
            print("Booking session..........")
        else:
            print("Invalid choice, try again")
            self.exercise(email)

    def consultation(self, email):
        print("Welcome to the Consultation therapy session \n You're being assigned to room 8")
        randos = list(itertools.product(self.days, self.times))
        with open('room8.data', 'rb') as file:
            # read the data as binary data stream
            self.room8 = pickle.load(file)
        file.close()
        room = [x for x in self.room8.keys()]
        for r in randos:
            if room.count(r) > 11:
                randos.remove(r)
        date = self.time(randos)

        if date in self.room8.keys():
            if self.room8[date] == email:
                print("You can't book twice in the same group session, try again")
                self.consultation(email)
        if room.count(date) > 11:
            print("This session is booked solid, try another one")
            self.consultation(email)
        elif email in self.room8.items():
            print("You can't book twice in the same group session")
            self.consultation(email)
        elif date in randos:
            self.room8[date] = email
            with open((email + '.data'),"rb") as file:
                user = pickle.load(file)
                if "consultation_group_booking" in user.keys():
                    user["consultation_group_booking"].append(date)
                else:
                    user["consultation_group_booking"] = [date]
            file.close()

            with open((email + '.data'),"wb") as file:
                pickle.dump(user, file)
            file.close()
            with open('room8.data', 'wb') as file:
                pickle.dump(self.room8, file)
            print("Booking session..........")
            file.close()
        else:
            print("Invalid choice, try again")
            self.consultation(email)
x = Headspace()
x.menu()
