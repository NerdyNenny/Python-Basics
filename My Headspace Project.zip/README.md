PROJECT NAME: MY HEADSPACE
CONTRIBUTORS:
Fareedah Okunade
Onyedikachi Onah
Nahashon Kariuki
PROJECT DESCRIPTION:
After the covid-19 pandemic, a lot of people have shown signs of struggling with their mental wellbeing.
MY HEADSPACE is the leading Mental Health Clinic in Kigali — and we have been managing our patients’ health since 2021.
We offer proactive and quality healthcare by offering three major activities: Haiku, art therapy and exercises therapy.
Our project works on providing an interface to interact with users. Using this project, the clinic should be able to:

● Sign Up for new users and Login for existing users
● Get a coping tip on every login
● Book sessions in our different rooms for the different therapeutic activities (6 rooms available, 2 rooms for each activity)
● Book a counseling session with our in-house psychologist Dr.Rasul
● For group therapies, each session can only take 10 people
● Pay for the service rendered
● Get a 5% discount if it’s a monthly booking and a 10% discount if it’s a yearly booking
● Get a 10% discount for first-time users


# MODULES USED IN THE PROGRAM
1. Random module: This is an in-built module used to generate random numbers or print a random value from a list or strings.
(ref: https://docs.python.org/3/library/random.html)

2. The Itertools Module: This module provides various functions to produce complex iterators. It is very fast, memory-efficient and
 can either be used alone or in combination with modules. (ref: https://docs.python.org/3/library/itertools.html)

3. The Pickle Module: This module implements binary protocols for serializing and de-serializing a python object structure.
(ref: https://docs.python.org/3/library/pickle.html)

4. The Unit Testing Framework: This module is used to test the functionality of our program in different scenarios.
(ref: https://docs.python.org/3/library/unittest.html)


To efficiently run this program, you need to have Pycharm and Python downloaded on your computer.
Always run the pre-installation files before running the actual program.

N.B: This project was written to be as simple and straightforward as possible.
However, it can be further improved and can accept more functionalities and flexibilities for users.