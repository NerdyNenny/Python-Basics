import unittest  # start by importing the unittest module that is used to test in python
from MyHeadSpace import Headspace  # import the class Headspace from the file MyHeadspace
from MyHeadSpace import Group  # import the class group from the file MyHeadspace


class MyTestCase(unittest.TestCase):  # create a class MyTestCase that inherits the unittest.TestCase
    def test_ask(self):  # test the first method under the class Headspace
        user1 = Headspace()  # create a user object for the class Headspace
        user1.ask()  # call the function with the object
        data = ["a", "b", "A", "B"]  # create a variable called data with a list of possible outcomes we expect from
        # the user
        self.assertEqual(user1.ask(), [data])  # check whether the user input is equal to what we expect using the
        # assertEqual function

    def test_signup_error(self, email):   # test the second method under the class Headspace
        user1 = Headspace()  # create a user object for the class Headspace
        user1.signup_error(email)  # the function to be tested with the object
        self.assertTrue(user1.signup_error(email="gg@gmail.com"))  # The email that is to be used to sign up

    def test_signup(self):   # test the third method under the class Headspace
        user1 = Headspace()  # create a user object for the class Headspace
        user1.signup()  # the function to be tested with the object
        self.assertTrue(user1.signup())  # checking if the user has successfully signed up

    def test_login_error(self, email):   # test the fourth method under the class Headspace
        user1 = Headspace()  # create a user object for the class Headspace
        user1.login_error(email)  # the function to tested with the object
        self.assertTrue(user1.login_error(email="gg@gmail.com")) # The email that is to be used to log in

    def test_password_error(self, email):   # test the fifth method under the class Headspace
        user1 = Headspace()  # create a user object for the class Headspace
        user1.password_error(email)  # the function to be tested with the object
        self.assertTrue(user1.password_error(email="gg@gmail.com"))  # The email that is to be used to log in

    def test_login(self):   # test the sixth method under the class Headspace
        user1 = Headspace()  # create a user object for the class Headspace
        user1.login()  # the function to be tested with the object
        self.assertTrue(user1.login())

    def test_tip(self, email):   # test the seventh method under the class Headspace
        user1 = Headspace()  # create a user object for the class Headspace
        user1.tip(email)  # the function to be tested with the object
        self.assertTrue(user1.tip(email="gg@gmail.com"))

    def test_art(self, email):   # test the eighth method under the class Headspace
        user1 = Headspace()  # create a user object for the class Headspace
        user1.art(email)  # the function to be tested with the object
        self.assertTrue(user1.art(email="gg@gmail.com"))

    def test_haiku(self, email):   # test the ninth method under the class Headspace
        user1 = Headspace()  # create a user object for the class Headspace
        user1.haiku(email)  # the function to be tested with the object
        self.assertTrue(user1.haiku(email="gg@gmail.com"))

    def test_exercise(self, email):   # test the tenth method under the class Headspace
        user1 = Headspace()  # create a user object for the class Headspace
        user1.exercise(email)   # the function to be tested with the object
        self.assertTrue(user1.exercise(email="gg@gmail.com"))

    def test_consultation(self, email):   # test the eleventh method under the class Headspace
        user1 = Headspace()  # create a user object for the class Headspace
        user1.consultation(email)   # the function to be tested with the object
        self.assertTrue(user1.consultation(email="gg@gmail.com"))

    def test_time(self, randos):   # test the twelfth method under the class Headspace
        user1 = Headspace()  # create a user object for the class Headspace
        user1.time()   # the function to be tested with the object
        self.assertTrue(user1.time())

    def test_pay(self, email):   # test the thirteenth method under the class Headspace
        user1 = Headspace()  # create a user object for the class Headspace
        user1.pay(email)   # the function to be tested with the object
        self.assertTrue(user1.pay(email="gg@gmail.com"))

    def test_menu(self):   # test the fourteenth method under the class Headspace
        user1 = Headspace()  # create a user object for the class Headspace
        user1.menu()   # the function to be tested with the object
        self.assertTrue(user1.menu())

    def test_choices(self, email):   # test the fifteenth method under the class Headspace
        user1 = Headspace()  #  # the function to be tested with the object
        self.assertTrue(user1.choices(email="gg@gmail.com"))

    def test_again(self, email):   # test the sixteenth method under the class Headspace
        user1 = Headspace()  # create a user object for the class Headspace
        user1.again(email)   # the function to be tested with the object
        self.assertTrue(user1.again(email="gg@gmail.com"))


if __name__ == '__main__':  # starts the test of the above functions
    unittest.main()


class MyTestCase(unittest.TestCase):  # create a class MyTestCase that inherits the unittest.TestCase
    def test_haiku(self, email):   # test the first method under the class Group
        user1 = Group()   # create a user object for the class Group
        user1.haiku(email)   # the function to be tested with the object
        self.assertTrue(user1.haiku(email="gg@gmail.com"))

    def test_art(self, email):  # test the second method under the class Group
        user1 = Group()   # create a user object for the class Group
        user1.art(email)   # the function to be tested with the object
        self.assertTrue(user1.art(email="gg@gmail.com"))

    def test_exercise(self, email):  # test the third method under the class Group
        user1 = Group()  # create a user object for the class Group
        user1.exercise(email)   # the function to be tested with the object
        self.assertTrue(user1.exercise(email="gg@gmail.com"))

    def test_consultation(self, email): # test the fourth method under the class Group
        user1 = Group()  # create a user object for the class Group
        user1.consultation(email)   # the function to be tested with the object
        self.assertTrue(user1.consultation(email="gg@gmail.com"))


if __name__ == '__main__':  # starts the test of the above functions
    unittest.main()