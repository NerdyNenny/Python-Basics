import random
import itertools

class Headspace:
#initialize the variables
    def __init__(self):
        #contains the list of users
        self.users = {"tennhy": "1904"}
        #contains the list of users that paid
        self.paid_users = []
        #contains the bookiings for each therapy room
        self.room1 = {}
        self.room2= {}
        self.room3 = {}
        self.room4 = {}
        self.room5 = {}
        self.room6 = {}
        self.room7 = {}
        self.room8 = {}
        #contains the times available for bookings
        self.times = ['10', '10:45', '11:30','12:15', '1:00', '1:45', '2:30','3:15','4:00','4:45','5:30','6:15']
        #contains the days available for bookings (with 1 for Monday and 6 for saturday)
        self.days = [1, 2, 3, 4, 5, 6]
        #contains the coping tips for users
        self.tips = ["sleep early", "stop overthinking", "take a walk"]
        #containsthe list of tips given to each user
        self.given = []

    #a method to collect user input
    def ask(self):
        #using input method to collect information, stripping whitespace with strip and replace, changing it to lowercase with lower()
        inputt = input("Enter here...").strip().replace(" ", "").lower()
        return inputt

    #a method to respond to an email existing error with the email for signup
    def signup_error(self,email):
        #telling the user that the email exists and to choose other options
        print("email exists, enter a to login to that account, b to signup for another account ")
        #calling the method for collecting user input
        choice = self.ask()
        #using if conditional to check if the user wants to try signing up again or logging in
        #if choice == a, call the login method
        if choice == "a":
            self.login()
        #if choice is b, call the signup method
        elif choice == "b":
            self.signup()
        #if it's none of the choices, tell the user invalid response and call the method again
        else:
            print("Invalid response, try again")
            self.signup_error(email)

    #this is the sign up  method
    def signup(self):
        #create a variable wrong to check the password later
        wrong = 0
        #asking user for their email
        print("Email...Only yahoo and gmail accepted currently")
        email = self.ask()
        #checking if it's an actual email by checking length and last ten characters of the email
        # Out of range exception handling
        try:
            if email[-10:] not in ["@gmail.com", "@yahoo.com"] or len(email) < 11:
                #if the email is not longer than 10 or doesn't contain the keywords of an email in the end, tell the user it's an invalid email and call signup function again
                print("Invalid email, enter again")
                self.signup()
                #if there is an out of range error(IndexError), tell the user it's an invalid email and call signup function again
        except IndexError:
            print("Invalid email, enter again")
            self.signup()
        #if the email passes the condition above then we check if the email is not already existing in the database
        #if the email exists, call the signup_error function
        if email in self.users.keys():
            self.signup_error(email)
        #if it doesn't exist then prompt for a password
        else:
            #using a while loop to check if the password satisfies some conditions
            while wrong == 0:
                print("Password - Enter 4 characters and above")
                #call the user input method
                password = self.ask()
                #if password less than 4 characters
                if len(password) < 4:
                    #tell the user the condition and let the loop keep on going
                    print("password cannot be empty or less than 4 characters")
                else:
                    #else if the password satisfies the condition,
                    #save the user's email and password to the dictionary
                    self.users[email] = password
                    #tell the user the signup was successfull
                    print("Signup successful", email)
                    #make wrong == 1, thereby stopping the loop
                    wrong += 1
        #return the email at the end
        return email

    #this method is meant for responding when the login email doesn't exist in the users dictionary
    def login_error(self,email):
        #tell the user their email doesn't exist and prompt for choices
        print("email doesn't exist, enter a to login to another account, b to signup for an account")
        #call the user input method
        choice = self.ask()
        #if the user's choice is a
        if choice == "a":
            #call the login method again
            self.login()
        #if the user's choice is b
        elif choice == "b":
            #call the signup method
            self.signup()
        #if the user's choice is neither
        else:
            #tell the user incorrect choice
            print("Invalid response, try again")
            #call the login_error method again
            self.login_error(email)

    #this method is meant for responding when the password doesn't correspond with the email
    def password_error(self,email):
        #ask the user for the password
        print("password........")
        #call the user input function to collect the password
        password = self.ask()
        #check if the password entered  is equal to that email's password in the dictionary
        if password == self.users[email]:
            #tell the user login successfull if it is
            print("Login successful")
        else:
            #if it's not, tell the user it's incorrect and call the password_error function again
            print("incorrect password")
            self.password_error(email)

    #this is the login method
    def login(self):
        #ask user for email
        print("Email")
        #call the user input function
        email = self.ask()
        #check if the email exists in users dictionary by key
        if email not in self.users.keys():
            #if  doesn't exist, call the login error method
            self.login_error(email)
        #f it exists, call the password_error function to collect password and check it
        else:
           self.password_error(email)
           #call the coping tips function
           self.tip(email)
           #finally return email
           return email

    #this is the tips function, gives user a coping tip upon login
    def tip(self,email):
        # this part of the method is ensuring we don't give the user the same tip twice
        #create another list and store the tips in it(created another list so we don't edit the original list)

        email_tips = self.tips
        #iterate through the new list and check if the tip is in the list of given tips
        for tip in email_tips:
            #if a tip from the new list created is in the given_tips list,
            if [email,tip] in self.given:
                #remove the tip from the new tips list created
                email_tips.remove(tip)
        #generate a random tip from the list and print that to the user
        tip = random.choice(email_tips)
        print("Coping tip for today:", tip)
        #add the tip given to the list of given tips
        self.given.append([email,tip])

    #this is the method for booking art therapy sessions
    def art(self,email):
        #print welcome to the user
        print("Welcome to the Art therapy session \n You're being assigned to room 1")
        #use the itertools module to create a list of the combinations of the times and days available for therapy
        #save it in the variable randos
        randos = list(itertools.product(self.days, self.times))
        #iterate through randos
        for r in randos:
            #for every day-time combo in the randos list, if the combination already exists in the room's keys,(that is if someone booked it already)
            if r in self.room1.keys():
                #remove the element from the list of combinations
                randos.remove(r)
        #call the time functions on the randos list to collect the user's prefereed date
        date = self.time(randos)
        #if user's choice  already exists in the room's keys
        if date in self.room1.keys():
            #tell the user the choice is already booked and call the art method again
            print("Choice is booked already, try again")
            self.art(email)
        #if the date exists in the list of randos, that means the time is still available
        elif date in randos:
            #save the user's email and date chosen as value and key in the room's dictionary
            self.room1[date] = email
            #tell the user that the session is being booked
            print("Booking session..........")
        # else if the condition doesn't meet any of the conditions above
        else:
           #tell the user they made an invalid choice and call the  art function again
            print("Invalid choice, try again")
            self.art(email)

    #this is the method for booking haiku therapy sessions
    def haiku(self,email):
        #print welcome to the user
        print("Welcome to the Haikutherapy session \n You're being assigned to room 3")
        # use the itertools module to create a list of the combinations of the times and days available for therapy
        # save it in the variable randos
        randos = list(itertools.product(self.days, self.times))
        # iterate through randos
        for r in randos:
            # for every day-time combo in the randos list, if the combination already exists in the room's keys,(that is if someone booked it already)
            if r in self.room3.keys():
                # remove the element from the list of combinations
                randos.remove(r)
        # call the time functions on the randos list to collect the user's prefereed date
        date = self.time(randos)
        if date in self.room3.keys():
            # tell the user the choice is already booked and call the haiku method again
            print("Choice is booked already, try again")
            self.haiku(email)
        # if the date exists in the list of randos, that means the time is still available
        elif date in randos:
            # save the user's email and date chosen as value and key in the room's dictionary
            self.room3[date] = email
            # tell the user that the session is being booked
            print("Booking session..........")
            # else if the condition doesn't meet any of the conditions above
        else:
            # tell the user they made an invalid choice and call the haiku function again
            print("Invalid choice, try again")
            self.haiku(email)

    #this is the method for booking exercise therapy sessions
    def exercise(self,email):
        #print welcome to the user
        print("Welcome to the Exercise therapy session \n You're being assigned to room 5")
        # use the itertools module to create a list of the combinations of the times and days available for therapy
        # save it in the variable randos
        randos = list(itertools.product(self.days, self.times))
        # iterate through randos
        for r in randos:
            # for every day-time combo in the randos list, if the combination already exists in the room's keys,(that is if someone booked it already)
            if r in self.room5.keys():
                # remove the element from the list of combinations
                randos.remove(r)
        # call the time functions on the randos list to collect the user's prefereed date
        date = self.time(randos)
        if date in self.room5.keys():
            # tell the user the choice is already booked and call the exercise method again
            print("Choice is booked already, try again")
            self.exercise(email)
        # if the date exists in the list of randos, that means the time is still available
        elif date in randos:
            # save the user's email and date chosen as value and key in the room's dictionary
            self.room5[date] = email
            # tell the user that the session is being booked
            print("Booking session..........")
            # else if the condition doesn't meet any of the conditions above
        else:
            # tell the user they made an invalid choice and call the exercise function again
            print("Invalid choice, try again")
            self.exercise(email)

    #this is the method for booking consultation sessions
    def consultation(self,email):
        #print welcome to the user
        print("Welcome to the consultation session \n You're being assigned to room 7")
        # use the itertools module to create a list of the combinations of the times and days available for therapy
        # save it in the variable randos
        randos = list(itertools.product(self.days, self.times))
        # iterate through randos
        for r in randos:
            # for every day-time combo in the randos list, if the combination already exists in the room's keys,(that is if someone booked it already)
            if r in self.room7.keys():
                # remove the element from the list of combinations
                randos.remove(r)
        # call the time functions on the randos list to collect the user's prefereed date
        date = self.time(randos)
        if date in self.room7.keys():
            # tell the user the choice is already booked and call the art method again
            print("Choice is booked already, try again")
        # if the date exists in the list of randos, that means the time is still available
        elif date in randos:
            # save the user's email and date chosen as value and key in the room's dictionary
            self.room7[date] = email
            # tell the user that the session is being booked
            print("Booking session..........")

        # else if the condition doesn't meet any of the conditions above
        else:
            # tell the user they made an invalid choice and call the consultation function again
            print("Invalid choice, try again")
            self.consultation(email)

    #this is the method for getting user's preferred date for booking
    def time(self,randos):
        #if the list of combinations of date and time is empty
        if randos == []:
            #tell the user the sessions are booked
            print("All sessions are booked")
        #else
        else:
            print("These are the times and days for sessions available.\n Enter the date preferred in the format displayed below")
            #iterate through each day and time in each combination and print in this format(0day - time)
            for x,y in randos:
                print( "0" + str(x) + " - " + y)
            #call the user input function to collect the user's preferred date
            date = self.ask()
            #creating a response for exceptions
            #returning  the day and time stripped of other characters
            try:
                return (int(date[1]),date[3:7])
            except IndexError:
                pass
            except ValueError:
                pass

    #this is the method for calculating user's bill
    def pay(self,email):
        #the standard bill for every service is $10, saved it to a variable bill
        bill = 10
        #ask the user what kind of booking they're making
        print("Enter A if the booking is one off \n Enter B if the booking is monthly \n Enter C if the booking is yearly")
        #calling the user input method to collect user's choice
        booking = self.ask()
        #if the booking choice is a,
        if booking == "a":
            #Tell the user their bill
            print("calculating bill......\n Your bill is $",bill)
        # if the booking choice is b,
        elif booking == "b":
            #Tell the user their bill - 5%
            bill = bill * 95/100
            print("calculating bill......\n You get a discount of 5% \n Your bill is $",bill)
        # if the booking choice is c
        elif booking == "c":
            #tell the user their bill - 10%
            bill = bill * 90/100
            print("calculating bill......\n You get a discount of 10% \n Your bill is $", bill )
        #else if the user input ddoesn't meet any of the above condition, print invalid unput
        else:
            print("Invalid input, try again")\
            #call the pay function again
            self.pay(email)
        #if the user's email is in the paid user's list
        if email in self.paid_users:
            #just proceed to payment
            print ("kindly pay on arrival")
        else:
            #else, remove an additional 10% and print the new bill
            bill = bill * 90 / 100
            print("As a new customer, you get a 10% discount \n Your new bill is ", bill)
            print("Kindly pay on arrival")
            #add the user's name to the paid user's list
            self.paid_users.append(email)

    #this is the method for printing a menu
    def menu(self):
        #welcome the user and ask to login or signup
        print("Welcome to my headspace \n Enter a to Login or b to Signup")
        #call the user input method and save it to the choice variable
        choice = self.ask()
        #if the user's choice is a
        if choice == "a":
            #call the login method
            email = self.login()
            #call the choices method
            self.choices(email)
        #if the user's choice is b
        elif choice == "b":
            #call the signup method
            email = self.signup()
            #call the choices method
            self.choices(email)
        else:
            #else if the user's choice is none of the above, tell the user invalid input and call the menu method again
            print("invalid response")
            self.menu()

    #this method contains a mini menu for the services rendered
    def choices(self,email):
        #ask the user what service they would like to perform
        print("Which service do you want to perform? \n Enter A for haiku \n Enter B for art \n Enter C for exercise \n Enter D for a consultation")
        #calling the user input method to store the user's choice into a variable choice
        choice = self.ask()
        #if the user's choice is a,
        if choice == "a":
            # call the haiku method
            self.haiku(email)
            #call the pay method
            self.pay(email)
            #call the again method
            self.again(email)
        #if the user's choice is b
        elif choice == "b":
            #call the art method
            self.art(email)
            # call the pay method
            self.pay(email)
            # call the again method
            self.again(email)
        #if the user's choice is c
        elif choice == "c":
            #call the exercise method
            self.exercise(email)
            # call the pay method
            self.pay(email)
            # call the again method
            self.again(email)
        #if the user's choice is d
        elif choice == "d":
            #call the consultation method
            self.consultation(email)
            # call the pay method
            self.pay(email)
            # call the again method
            self.again(email)
        #else if the user's choice is none of the above, tell the user it's an invalid input
        else:
            print("Invalid input, try again")
            #start the method from the beginnning
            self.choices(email)

    #this method checks if the user wants to perform another action
    def again(self,email):
        #tell the user to enter yes or no
        print("Do you want to perform any other transaction? \n Enter Yes or No")
        #calling the user input method to get the user's decision and saving it to a variable named choice.
        #selecting only the first letter incase of mispellings on the user's part
        choice = self.ask()[0]
        #if the user's choice is yes
        if choice == "y":
            #call the choices method
            self.choices(email)
        #if the user's choice is no
        elif choice == "n":
            #tell the user thank you
            print("Thank you for using my headspace")
        #else if the user's choice is none of the above, tell the user invallid input
        else:
            print("Invalid input, try again")
            #start the method from the beginnning
            self.again(email)

#this class is a child class of Headspace called Group. This is for booking group therapy sessions
class Group(Headspace):

    #this is the method for booking group haiku therapy sessions
    def haiku(self,email):
        # print welcome to the user
        print("Welcome to the Haiku group therapy session \n You're being assigned to room 4")
        # use the itertools module to create a list of the combinations of the times and days available for therapy
        # save it in the variable randos
        randos = list(itertools.product(self.days, self.times))
        #creating a list containing the room's dictionary keys by iterating since the room's dictionary keys is not editable
        room = [x for x in self.room4.keys()]
        #iterate through the randos list
        for r in randos:
            #if there's any day-time combination from randos that has appeared 10 times or more in the room list
            if room.count(r) >= 10:
                #remove the day-time combination from the randos list
                randos.remove(r)
        #call the time method on the updated list to get the user's preferred date
        date = self.time(randos)

        #now checking if the user's preferred date is in the room's dictionary keys
        if date in self.room4.keys():
            #if it is, check if it's that user that booked it before by checking the dictionary's key value
            if self.room4[date] == email:
                #if it is, then tell the user they can't book twice
                print("You can't book twice in the same group session, try again")
                #start the method from the beginning
                self.haiku(email)
        #if the room's dictionary already has that date appearing 10 times
        elif room.count(date) >= 10:
            #tell the user that session is not available again
            print("This session is booked solid, try another one")
            #call the haiku method again
            self.haiku(email)
        #else if the date chosen is in the combination list(randos)
        elif date in randos:
            # save the user's email and date chosen as value and key in the room's dictionary
            self.room4[date] = email
            # tell the user that the session is being booked
            print("Booking session..........")
        # else if the condition doesn't meet any of the conditions above
        else:
            # tell the user they made an invalid choice and call the haiku function again
            print("Invalid choice, try again")
            self.haiku(email)

    # this is the method for booking group art therapy sessions
    def art(self, email):
        # print welcome to the user
        print("Welcome to the Art group therapy session \n You're being assigned to room 2")
        # use the itertools module to create a list of the combinations of the times and days available for therapy
        # save it in the variable randos
        randos = list(itertools.product(self.days, self.times))
        # creating a list containing the room's dictionary keys by iterating since the room's dictionary keys is not editable
        room = [x for x in self.room2.keys()]
        # iterate through the randos list
        for r in randos:
            # if there's any day-time combination from randos that has appeared 10 times or more in the room list
            if room.count(r) >= 10:
                # remove the day-time combination from the randos list
                randos.remove(r)
        # call the time method on the updated list to get the user's preferred date
        date = self.time(randos)

        # now checking if the user's preferred date is in the room's dictionary keys
        if date in self.room2.keys():
            # if it is, check if it's that user that booked it before by checking the dictionary's key value
            if self.room2[date] == email:
                # if it is, then tell the user they can't book twice
                print("You can't book twice in the same group session, try again")
                # start the method from the beginning
                self.art(email)
        # if the room's dictionary already has that date appearing 10 times
        elif room.count(date) >= 10:
            # tell the user that session is not available again
            print("This session is booked solid, try another one")
            # call the art method again
            self.art(email)
        # else if the date chosen is in the combination list(randos)
        elif date in randos:
            # save the user's email and date chosen as value and key in the room's dictionary
            self.room2[date] = email
            # tell the user that the session is being booked
            print("Booking session..........")
            # else if the condition doesn't meet any of the conditions above
        else:
            # tell the user they made an invalid choice and call the artfunction again
            print("Invalid choice, try again")
            self.art(email)

    # this is the method for booking group exercise therapy sessions
    def exercise(self, email):
        # print welcome to the user
        print("Welcome to the Exercise group therapy session \n You're being assigned to room 6")
        # use the itertools module to create a list of the combinations of the times and days available for therapy
        # save it in the variable randos
        randos = list(itertools.product(self.days, self.times))
        # creating a list containing the room's dictionary keys by iterating since the room's dictionary keys is not editable
        room = [x for x in self.room6.keys()]
        # iterate through the randos list
        for r in randos:
            # if there's any day-time combination from randos that has appeared 10 times or more in the room list
            if room.count(r) >= 10:
                # remove the day-time combination from the randos list
                randos.remove(r)
        # call the time method on the updated list to get the user's preferred date
        date = self.time(randos)

        # now checking if the user's preferred date is in the room's dictionary keys
        if date in self.room6.keys():
            # if it is, check if it's that user that booked it before by checking the dictionary's key value
            if self.room6[date] == email:
                # if it is, then tell the user they can't book twice
                print("You can't book twice in the same group session, try again")
                # start the method from the beginning
                self.exercise(email)
        # if the room's dictionary already has that date appearing 10 times
        elif room.count(date) >= 10:
            # tell the user that session is not available again
            print("This session is booked solid, try another one")
            # call the exercise method again
            self.exercise(email)
        # else if the date chosen is in the combination list(randos)
        elif date in randos:
            # save the user's email and date chosen as value and key in the room's dictionary
            self.room6[date] = email
            # tell the user that the session is being booked
            print("Booking session..........")
            # else if the condition doesn't meet any of the conditions above
        else:
            # tell the user they made an invalid choice and call the exercise function again
            print("Invalid choice, try again")
            self.exercise(email)

        # this is the method for booking group haiku therapy sessions

    # this is the method for booking group consultation therapy sessions
    def consultation(self, email):
        # print welcome to the user
        print("Welcome to the Consultation group therapy session \n You're being assigned to room 8")
        # use the itertools module to create a list of the combinations of the times and days available for therapy
        # save it in the variable randos
        randos = list(itertools.product(self.days, self.times))
        # creating a list containing the room's dictionary keys by iterating since the room's dictionary keys is not editable
        room = [x for x in self.room8.keys()]
        # iterate through the randos list
        for r in randos:
            # if there's any day-time combination from randos that has appeared 10 times or more in the room list
            if room.count(r) >= 10:
                # remove the day-time combination from the randos list
                randos.remove(r)
        # call the time method on the updated list to get the user's preferred date
        date = self.time(randos)

        # now checking if the user's preferred date is in the room's dictionary keys
        if date in self.room8.keys():
            # if it is, check if it's that user that booked it before by checking the dictionary's key value
            if self.room8[date] == email:
                # if it is, then tell the user they can't book twice
                print("You can't book twice in the same group session, try again")
                # start the method from the beginning
                self.consultation(email)
        # if the room's dictionary already has that date appearing 10 times
        elif room.count(date) >= 10:
            # tell the user that session is not available again
            print("This session is booked solid, try another one")
            # call the consultation method again
            self.consultation(email)
        # else if the date chosen is in the combination list(randos)
        elif date in randos:
            # save the user's email and date chosen as value and key in the room's dictionary
            self.room8[date] = email
            # tell the user that the session is being booked
            print("Booking session..........")
            # else if the condition doesn't meet any of the conditions above
        else:
            # tell the user they made an invalid choice and call the consultation function again
            print("Invalid choice, try again")
            self.consultation(email)
x = Group()
x.menu()