import pickle
with open('users.data', 'wb') as file:
    pickle.dump({}, file)
for i in range(1,9):
    with open('room' + str(i) + '.data', 'wb') as file:
        pickle.dump({}, file)
with open('paid_users.data', 'wb') as file:
    pickle.dump([], file)
with open('given.data', 'wb') as file:
    pickle.dump([], file)
